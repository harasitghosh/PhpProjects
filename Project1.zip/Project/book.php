<?php
include "ck.php";
$sid=$_REQUEST['sl'];
date_default_timezone_set("asia/kolkata");
$datetime = date('d/m/Y h:i:s a', time());
$query = "INSERT INTO book (cid,sid,dttm) VALUES ('$user_currently_loged','$sid','$datetime')";
$result = mysqli_query($conn,$query) or die (mysqli_error());
?>

<script language="javascript">
alert('Booked Successfully. Thank You');
document.location="index.php";
</script>
