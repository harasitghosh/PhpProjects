<?php 
include 'admin/connection.php';
$sl=$_REQUEST['sl'];

$getta=mysqli_query($conn,"select * from user where sl='$sl'") or die(mysqli_error());
	while($ro=mysqli_fetch_array($getta))
	{	
		$name=$ro['name'];
		$email=$ro['email'];
		$cat=$ro['catnm'];
		$subcat=$ro['subcat'];
        $address=$ro['address'];
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/edit.css">
</head>
<body>
<form action="value3.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="sl" id="sl" value="<?PHP echo $sl;?>">
        <table border="0" align="center"> <br>
            <tr>
                <td>Category</td>
                <td>

                <select name="cat" id="cat" onchange="fun(this.value)" data-error="Name is required." required="required">
                    <option value="0">Choose Category</option>
                    <?php
                    $query=mysqli_query($conn,"select * from category order by sl") or die (mysqli_error());
                    while($data=mysqli_fetch_array($query))
                    {
                        $catid=$data['sl'];
                        $catnm=$data['catnm'];
                        ?>
                    <option value="<?php echo $catid;?>" <?=($catid==$cat)?'Selected':'';?>> <?php echo $catnm ;?></option>
                    <?php
                    }
                    ?>
                </select>

                </td>
                <tr>
                    <td>Sub Category</td>
                    <td>
                    <div  id="divsubcat" >
                        <select name="subcat" id="subcat" data-error="Name is required." required="required" style="width:70px">
                        <?php
                    $query=mysqli_query($conn,"select * from subcategory order by sl") or die (mysqli_error());
                    while($data=mysqli_fetch_array($query))
                    {
                        $catid=$data['sl'];
                        $subcatnm=$data['subcat'];
                        ?>
                            <option value="<?php echo $catid;?>" <?=($catid==$subcat)?'Selected':'';?>><?php echo $subcatnm ;?></option>
                            <?php
                    }
                            ?>
                        </select>
                    </div>
                    </td>
                </tr>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="nm" id="nm" autocomplete="off" required="required" value="<?PHP echo $name;?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" autocomplete="off" required="required" value="<?PHP echo $email;?>"></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><input type="text" name="add" id="add" autocomplete="off" required="required" value="<?PHP echo $address;?>"></td>
            </tr>

            
            <tr>
                <td colspan="2" align="center"><input type="submit"  value=" UPDATE"name="submit" class="button"></td>
            </tr>
        </table>
    </form> <br>

</body>
</html>