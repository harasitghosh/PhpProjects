<?php
include "connection.php";

$catnm=$_POST['cat'];
$subcat=$_POST['subcat'];
$name=$_POST['nm'];
$contact=$_POST['no'];
$email=$_POST['email'];
$address=$_POST['add'];
if(isset($_POST['sl']))
{
  $sl=$_POST['sl'];
}
else
{
  $sl="";
}


if($sl=='')
{
$a=$_FILES["file"]["size"];
$b=$a/1024;
//echo $b."Kb<br>";
$allowedExts = array("gif", "jpeg", "jpg", "png" ,"GIF","JPEG","JPG","PNG");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if (($_FILES["file"]["size"] <=5000000)&& in_array($extension, $allowedExts))
{
    if(file_exists("pic/" .$contact.".png"))
    {
        //echo $contact.".png already exists. ";
    }
    else
    {
        $picname="pic/".$contact.".png";
      move_uploaded_file($_FILES["file"]["tmp_name"],$picname);
	    //echo "file uploded!";
    }
 }
else
  {
  echo "Invalid file";
  }


  $f=0;
  $getta=mysqli_query($conn,"select * from user where contact='$contact' and email='$email' and catnm='$catnm' and subcat='$subcat' ") or die(mysqli_error());
	while($ro=mysqli_fetch_array($getta))
{	
	  $f++;
}	

  if($f==0)
  {	
    
  $query = "INSERT INTO user (name,contact,email,address,catnm,subcat) VALUES ('$name','$contact','$email','$address','$catnm','$subcat')";
  $result = mysqli_query($conn,$query) or die (mysqli_error());
  ?>
  <script language="javascript">
  alert('Submited Successfully. Thank You');
  document.location="user.php";
  </script>
  <?php
  }
  else
  {
  ?>
  <script language="javascript">
  alert('Duplicate Data!!');
  window.history.back();
  </script>
  <?php	
  }
}
else
{
  $f=0;
  $getta=mysqli_query($conn,"select * from user where contact='$contact' and email='$email' and catnm='$catnm' and subcat='$subcat' ") or die(mysqli_error());
	while($ro=mysqli_fetch_array($getta))
{	
	  $f++;
}	

  if($f==0)
  {	
  $query = "update user set name='$name',email='$email',address='$address',catnm='$catnm' ,subcat='$subcat' where sl='$sl'";
  $result = mysqli_query($conn,$query) or die (mysqli_error());
  ?>
  <script language="javascript">
  alert('Updated Successfully. Thank You');
  document.location="user.php";
  </script>
  <?php
  }
  else
  {
  ?>
  <script language="javascript">
  alert('Duplicate Data!!');
  window.history.back();
  </script>
  <?php	
  }
}
?>


