<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>



        <!--====== Required meta tags ======-->
        <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Document</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="images\favicon.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="css\slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="css\animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="css\nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="css\jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="css\magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="css\bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="css\font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="css\default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="css\style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="css\responsive.css">
    
</head>
<body>
<header id="header-part">        
        <div class="navigation navigation-2 navigation-3">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-11 col-md-10 col-sm-9 col-9">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                               <!-- <img src="images\category\logo.jpg" alt="" width="60px" height="60px"> -->
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    <li class="nav-item">
                                        <a class="active" href="index.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.html">About us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="services.html">Services</a>
                                    </li>
                                  

                                    <li class="nav-item">
                                        <a href="contact.html">Contact</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a href="mybook2.php">My Bookings</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="login_details/logoff.php">Log Out</a>
                                    </li>
                                </ul>
                            </div>
                        </nav> <!-- nav -->
                    </div>
                   
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
    </header>



    <!--====== jquery js ======-->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js\vendor\modernizr-3.6.0.min.js"></script>
    <script src="js\vendor\jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="js\bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="js\slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="js\jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="js\waypoints.min.js"></script>
    <script src="js\jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="js\jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="js\jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="js\jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="js\validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="js\ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="js\main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="js\map-script.js"></script>
    
</body>
</html>