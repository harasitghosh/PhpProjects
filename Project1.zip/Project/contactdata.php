<?php
include "connection.php";

$name=$_POST['name'];
$email=$_POST['email'];
$occupation=$_POST['occupation'];
$phone=$_POST['phone'];
$messege=$_POST['messege'];

$query = "INSERT INTO contactdata (name,email,occupation,phone,messege) VALUES ('$name','$email','$occupation','$phone','$messege')";
$result = mysqli_query($conn,$query) or die (mysqli_error());
?>

<script language="javascript">
alert('Submited Successfully. Thank You');
document.location="contact.html";
</script>