<?php
include "connection.php";
$cat=$_REQUEST['cat'];

?>
 <select name="subcat" id="subcat">
       <option value="">--select--</option>
        <?php
        $query=mysqli_query($conn,"select * from subcategory where catid='$cat' order by subcat") or die (mysqli_error());
         while($data=mysqli_fetch_array($query))
        {
        $subcatid=$data['sl'];
        $subcat=$data['subcat'];
        ?>
         <option value="<?php echo $subcatid;?>"> <?php echo $subcat ;?></option>
        <?php
        }
        ?>
</select>