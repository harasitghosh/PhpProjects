﻿<?php
include "admin/connection.php";
session_start();
if(isset($_SESSION['id']))
{
  $id=$_SESSION['id'];
}
else
{
	$id="";
}
?>
<!doctype html>
<html lang="en">

<head>
   
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Document</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="images\favicon.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="css\slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="css\animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="css\nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="css\jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="css\magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="css\bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="css\font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="css\default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="css\style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="css\responsive.css">
    

<script>
function fun(cat)
 { 
    //alert(cat);
    $('#divsubcat').load('admin/getsubcat2.php?cat='+cat).fadeIn('fast');
 }
</script>
</head>

<body>
   
   <!--====== PRELOADER PART START ======-->
    
    <div class="preloader">
        <div class="loader rubix-cube">
            <div class="layer layer-1"></div>
            <div class="layer layer-2"></div>
            <div class="layer layer-3 color-1"></div>
            <div class="layer layer-4"></div>
            <div class="layer layer-5"></div>
            <div class="layer layer-6"></div>
            <div class="layer layer-7"></div>
            <div class="layer layer-8"></div>
        </div>
    </div>
    
    <!--====== PRELOADER PART START ======-->
   
    <!--====== HEADER PART START ======-->
    
    <header id="header-part">        
        <div class="navigation navigation-2 navigation-3">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-11 col-md-10 col-sm-9 col-9">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                               <!-- <img src="images\category\logo.jpg" alt="" width="60px" height="60px"> -->
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    <li class="nav-item">
                                        <a class="active" href="index.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.html">About us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="services.html">Services</a>
                                    </li>
                                  

                                    <li class="nav-item">
                                        <a href="contact.html">Contact</a>
                                    </li>
                                    <li class="nav-item">
                                        <?php
                                        if($id=='')
                                        {
                                        ?>
                                    <a href="login_details/login.php">Login</a>
                                        <ul class="sub-menu">
                                           <!--  <li><a href="login_details/login.php">Log In</a></li>
                                            <li><a href="login_details/login.php">Service  Provider</a></li>
                                            <li><a href="login_details/login.php">User</a></li> -->
                                        </ul>
                                   <?php
                                        }
                                        else
                                        {
                                        ?>
                                     <a href="login_details/logoff.php">Logout</a>
                                     <li class="nav-item">
                                        <a href="mybook.php">My Bookings</a>
                                    </li>

                                    <?php   
                                     }
                                   ?>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#">Register</a>
                                        <ul class="sub-menu">
                                            <li><a href="login_details/signup2.php">User Register</a></li>
                                            <li><a href="login_details/signup.php">Service  provider</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav> <!-- nav -->
                    </div>
                   
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
    </header>
    
    <!--====== HEADER PART ENDS ======-->
   
    
   
    <!--====== SLIDER PART START ======-->
    
    <section id="slider-part-3" class="bg_cover" style="background-image: url(images/slider/s-3.jpeg)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="slider-cont-3 text-center">
                        <h2>Search for Get Experts</h2>
                        <span>More then 300+ Experts for you</span>
                        <div class="slider-search mt-45">
                           <form action="search.php" method="post">
                                <div class="row no-gutters">
                                    <div class="col-sm-3" >
                                        <select name="cat" id="cat" onchange="fun(this.value)">
                                            <option value="0">Choose Category</option>

                                            <?php
                                                $query=mysqli_query($conn,"select * from category order by sl") or die (mysqli_error());
                                                while($data=mysqli_fetch_array($query))
                                                {
                                                    $catid=$data['sl'];
                                                    $catnm=$data['catnm'];
                                                ?>
                                                <option value="<?php echo $catid;?>"> <?php echo $catnm ;?></option>
                                                <?php
                                                }
                                                ?>

                                        </select>
                                    </div>
                                    <div class="col-sm-6" id="divsubcat" >
                                        <select class="nice-select" tab name="subcat" id="subcat">
                                            <option value="">--select--</option>
                                        </select>
                                      <!--  <input type="text" placeholder="Search keyword"> -->
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="main-btn" name="search" id="search">Get Experts</button>
                                    </div>
                                </div> <!-- row -->
                            </form>
                        </div>
                    </div> <!-- slider cont3 -->
                </div>
            </div> <!-- row -->
            <div class="slider-feature pt-30 d-none d-md-block">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="singel-slider-feature justify-content-center mt-30">
                            <div class="icon">
                                <img src="images\all-icon\man.png" alt="icon">
                            </div>
                            <div class="cont">
                                <h3>300 +</h3>
                                <span>Worldwide Experts</span>
                            </div>
                        </div> <!-- singel slider feature -->
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="singel-slider-feature justify-content-center mt-30">
                            <div class="icon">
                                <img src="images\all-icon\book.png" alt="icon">
                            </div>
                            <div class="cont">
                                <h3>150 +</h3>
                                <span>Available Services</span>
                            </div>
                        </div> <!-- singel slider feature -->
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="singel-slider-feature justify-content-center mt-30">
                            <div class="icon">
                                <img src="images\all-icon\expert.png" alt="icon">
                            </div>
                            <div class="cont">
                                <h3>Expert Instructor</h3>
                                <span>Expert Instructors</span>
                            </div>
                        </div><!-- singel slider feature -->
                    </div>
                </div> <!-- row -->
            </div> <!-- slider feature -->
        </div> <!-- container -->
    </section>
    
    <!--====== SLIDER PART ENDS ======-->
    
    <!--====== CATEGORY PART START ======-->
    
    <section id="category-3" class="category-2-items pt-50 pb-80 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="singel-items text-center mt-30">
                        <div class="items-image">
                        <img src="images\category\ctg-1.jpeg" alt="Category">
                        </div>
                        <div class="items-cont">
                            <a href="#">
                                <h5>Web Developer</h5>
                                <span>24*7 Available</span>
                            </a>
                        </div>
                    </div> <!-- singel items -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="singel-items text-center mt-30">
                        <div class="items-image">
                            <img src="images\category\ctg-1.jpeg" alt="Category">
                        </div>
                        <div class="items-cont">
                            <a href="#">
                                <h5>UI/ UX Design</h5>
                                <span>24*7 Available</span>
                            </a>
                        </div>
                    </div> <!-- singel items -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="singel-items text-center mt-30">
                        <div class="items-image">
                            <img src="images\category\ctg-1.jpeg" alt="Category">
                        </div>
                        <div class="items-cont">
                            <a href="#">
                                <h5>App development</h5>
                                <span>24*7 Available</span>
                            </a>
                        </div>
                    </div> <!-- singel items -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="singel-items text-center mt-30">
                        <div class="items-image">
                            <img src="images\category\ctg-1.jpeg" alt="Category">
                        </div>
                        <div class="items-cont">
                            <a href="#">
                                <h5>Web Page Designing</h5>
                                <span>24*7 Available</span>
                            </a>
                        </div>
                    </div> <!-- singel items -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== CATEGORY PART ENDS ======-->
    
    
   
    
    <!--====== COUNTER PART START ======-->
    
    <div id="counter-part" class="bg_cover pt-25 pb-70 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-counter counter-3 text-center mt-40">
                        <span><span class="counter">10,000</span>+</span>
                        <p>User enrolled</p>
                    </div> <!-- singel counter -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-counter counter-3 text-center mt-40">
                        <span><span class="counter">150</span>+</span>
                        <p>Available Services</p>
                    </div> <!-- singel counter -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-counter counter-3 text-center mt-40">
                        <span><span class="counter">100</span>+</span>
                        <p> certified Experts</p>
                    </div> <!-- singel counter -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="singel-counter counter-3 text-center mt-40">
                        <span><span class="counter">40</span>+</span>
                        <p>Global Experts</p>
                    </div> <!-- singel counter -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    
    <!--====== COUNTER PART ENDS ======-->
    
    <!--====== EXPERTS PART START ======-->
    
    <section id="teachers-part" class="pt-65 pb-120 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title mt-50 pb-25">
                        <h5>Top Experts</h5>
                        <h2>Featured Experts</h2>
                    </div> <!-- section title -->
                    <div class="teachers-2">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="teachers-2-singel mt-30">
                                    <div class="thum">
                                        <img src="images\experts\experts-2\tc-1.jpeg" alt="Teacher">
                                    </div>
                                    <div class="cont">
                                        <a href="#"><h5>Goutam Pramanick</h5></a>
                                        <p>Personality Development Expert</p>
                                    </div>
                                </div> <!-- teachers 2 singel -->
                            </div>
                            <div class="col-md-6">
                                <div class="teachers-2-singel mt-30">
                                    <div class="thum">
                                        <img src="images\experts\experts-2\tc-2.jpeg" alt="Teacher">
                                    </div>
                                    <div class="cont">
                                        <a href="#"><h5>Pritam Sarkar</h5></a>
                                        <p>Fitness Expert</p>
                                    </div>
                                </div> <!-- teachers 2 singel -->
                            </div>
                            <div class="col-md-6">
                                <div class="teachers-2-singel mt-30">
                                    <div class="thum">
                                        <img src="images\experts\experts-2\tc-3.jpeg" alt="Teacher" width="65px">
                                    </div>
                                    <div class="cont">
                                        <a href="#"><h5>Ibrah Noor</h5></a>
                                        <p>Advaisor Expert</p>
                                    </div>
                                </div> <!-- teachers 2 singel -->
                            </div>
                            <div class="col-md-6">
                                <div class="teachers-2-singel mt-30">
                                    <div class="thum">
                                        <img src="images\experts\experts-2\tc-4.jpeg" alt="Teacher" width="65px">
                                    </div>
                                    <div class="cont">
                                        <a href="#"><h5>Soumik Ghosh </h5></a>
                                        <p>Computer Expert</p>
                                    </div>
                                </div> <!-- teachers 2 singel -->
                            </div>
                        </div> <!-- row -->
                    </div> <!-- teachers 2 -->
                </div>
                <div class="col-lg-6 ">
                    <div class="happy-student mt-55">
                        <div class="happy-title">
                            <h3>Happy Clints</h3>
                        </div>
                        <div class="student-slied">
                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Argha Dutta</h6>
                                <span></span>
                            </div> <!-- singel student -->
                            
                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Harasit Ghosh</h6>
                                <span></span>
                            </div> <!-- singel student -->

                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Indranil Kundu</h6>
                                <span></span>
                            </div> <!-- singel student -->

                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Pijush Debnath</h6>
                                <span></span>
                            </div> <!-- singel student -->

                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Rahul Ghosh</h6>
                                <span></span>
                            </div> <!-- singel student -->

                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Sribasish Naskar</h6>
                                <span></span>
                            </div> <!-- singel student -->
                            
                            <div class="singel-student">
                                <img src="images\experts\experts-2\quote.png" alt="Quote">
                                <p>Aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet</p>
                                <h6>Shahensha Alam</h6>
                                <span>Bsc, Engineering</span>
                            </div> <!-- singel student -->

                        </div> <!-- student slied -->
                        <div class="student-image">
                            <img src="images\experts\experts-2\happy.png" alt="Image">
                        </div>
                    </div> <!-- happy student -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== EXPERTS  PART ENDS ======-->
   
   
    <!--====== FOOTER PART START ======-->
    <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img src="images\logo3.jpg" alt="Logo" width="25%"></a>
                            </div>
                            <p>Now a Days peoples are Busy at their professional life and they have not sufficient time for some others small work, it’s not only our country problem it is the problem of whole world. So we came here with a best solution of this problems with Proplic. It not just a solution but also it saves our time and money also. Proplic is a Website/ Web Application that offers the solution of online all kind of service that need of daily life</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="index.php"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>About us</a></li>

                            </ul>
                            <ul>

                                <li><a href="#"><i class="fa fa-angle-right"></i>Services</a></li>
                                <li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy & policy</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <div class="cont">
                                        <p>32 Mahatma Gandhi Road, North Kolkata </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+3 123 456 789</p>
                                    </div>
                                </li>
                                
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="copyright text-md-left text-center pt-15">
                            <p>&copy; Copyrights 2022 Proplic All rights reserved. </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                            <p>Designed by <span>Harasit</span> </p>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
    
    <!--====== BACK TO TP PART ENDS ======-->
   
    

    
    <!--====== jquery js ======-->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js\vendor\modernizr-3.6.0.min.js"></script>
    <script src="js\vendor\jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="js\bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="js\slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="js\jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="js\waypoints.min.js"></script>
    <script src="js\jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="js\jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="js\jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="js\jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="js\validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="js\ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="js\main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="js\map-script.js"></script>

</body>

</html>
