<?php
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/search.css">
</head>
<body> <br><br>

<?php
$cat=$_POST['cat'];
$subcat=$_POST['subcat'];

if(isset($_POST['search']))
{   
    $get=mysqli_query($conn,"select * from category where sl='$cat'") or die(mysqli_error());
    while($ro1=mysqli_fetch_array($get))
    {	
        $catnm=$ro1['catnm'];
    }

    $query3=mysqli_query($conn, "select * from subcategory  where sl='$subcat'") or die (mysqli_error());
       while($data3=mysqli_fetch_array($query3))
       {   
           
           $subcatnm=$data3['subcat'];
       }
           
         
    $query=mysqli_query($conn, "select * from user where catnm='$cat' and subcat='$subcat' and stat='1' ") or die (mysqli_error());

    while($data=mysqli_fetch_array($query))
    {
               $name=$data['name'];
               $address=$data['address'];
               $contact=$data['contact'];
               //$sl=$data['sl'];
?>


<section class="middle" id="home">
        <div class="card1">
            <img src="pic/<?php echo $contact?>.png" width="100px"><br>
                <h1>Name: <?php echo $name ; ?></h1>
                <h1>Address : <?Php echo $address;?></h1>
              <!--  <h1>category:<?php ?></h1> -->
                <h1>category:<?php echo $subcatnm;?></h1>
        <button><a href="book.php?sl=<?php echo $contact;?>">Book Now</a></button>
        </div>
</section>

<?php
    }
}
?>
</body>
</html>

