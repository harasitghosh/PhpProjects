<?php
include "connection.php";
include "ck.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/mybook.css">
</head>
<body>
  
<div class="info">
    <?php
        $f=0;
        $query="SELECT * FROM `book` where cid='$user_currently_loged' ORDER BY sl DESC";
        $data=mysqli_query($conn,$query);
        $total=mysqli_num_rows($data);
        if($total!=0){
          while($result=mysqli_fetch_array($data))
          {
            $f++;
            $sl=$result['sl'];
            $cid=$result['cid'];
            $sid=$result['sid'];
            $time=$result['dttm'];
            $stat=$result['stat'];
            $canceldate= $result['canceldate'];
          
     
        ?>
        <div class="card">
        <div class="info">
        <?php
            $query1="SELECT * FROM `user` WHERE contact='$sid'";
            $data1=mysqli_query($conn,$query1);
            while($result1=mysqli_fetch_array($data1)){
              $name = $result1['name'];
              $catid = $result1['catnm'];
              $subcatid = $result1['subcat'];
              $address = $result1['address'];

              $get=mysqli_query($conn,"select * from category where sl='$catid'") or die(mysqli_error());
              while($ro1=mysqli_fetch_array($get))
              {	
                  $catnm=$ro1['catnm'];
              }

              $get=mysqli_query($conn,"select * from subcategory where sl='$subcatid'") or die(mysqli_error());
              while($ro1=mysqli_fetch_array($get))
              {	
                  $subcat=$ro1['subcat'];
              }
            }
   
        ?>
        <section class="middle" id="home">
        <div class="card1">
           <img src="pic/<?php echo $sid?>.png" width="100px"><br>
            <h3> Name :<?php echo $name; ?> </h3>
            <h3>Category :<?php echo $catnm;?></h3>
            <h3>Sub Category :<?php echo $subcat;?></h3>
            <h3>Address :<?php echo $address;?></h3>
            <h3>Time :<?php echo $time;?></h3>
            <?php
            if($stat==1)
            {
            ?>
            <button><a href="cancel.php?sl=<?php echo$sl;?>">Cancel</a></button>
            <?php
            }
            else
            {?>
            <button>Canceled on <?php echo $canceldate;?></button>
           <?php }
            ?>
        </div>
        </section>
    <?php
    }
}
else
{
?>
   <h1 style="color:blue; margin: 300px 450px; font-size: 50px">No Booking !!!!</h1>
<?php
}
 ?>
    
</div>
</div>
</div>
</body>
</html>

