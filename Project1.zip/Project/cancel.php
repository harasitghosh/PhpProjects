<?php
include "connection.php";

$sl=$_REQUEST['sl'];
date_default_timezone_set("asia/kolkata");
$datetime = date('d/m/Y h:i:sa', time());

$query = "update book set stat='0',canceldate='$datetime' where sl='$sl'";
$result = mysqli_query($conn,$query)or die (mysqli_error());
?>
<script language="javascript">
alert('Done Successfully. Thank You');
document.location="mybook.php";
</script>
