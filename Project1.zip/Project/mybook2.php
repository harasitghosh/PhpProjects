<?php
include "connection.php";
include "ck.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/mybook.css">
</head>
<body>
  
<div class="info">
    <?php
        $f=0;
        $query="SELECT * FROM `book` where sid='$user_currently_loged' and stat='1' ORDER BY sl DESC";
        $data=mysqli_query($conn,$query);
        $total=mysqli_num_rows($data);
        if($total!=0){
          while($result=mysqli_fetch_array($data))
          {
            $f++;
            $sl=$result['sl'];
            $cid=$result['cid'];
            $sid=$result['sid'];
            $time=$result['dttm'];
            //$canceldate= $result['canceldate'];
          
       
        ?>
        <div class="card">
          <?php
          
          ?>
        <div class="info">
        <?php
            $query1="SELECT * FROM `main_signup` WHERE mob='$cid'";
            $data1=mysqli_query($conn,$query1);
            while($result1=mysqli_fetch_array($data1))
            {
              $name = $result1['name'];
              $contact = $result1['mob'];
              $email = $result1['mailadres'];
            }
        ?>
        <section class="middle" id="home">
        <div class="card1">
           <img src="pic/<?php echo $sid?>.png" width="100px"><br>
            <h3> Name :<?php echo $name; ?> </h3>
            <h3>Mobile.No :<?php echo $contact;?></h3>
            <h3>Email :<?php echo $email;?></h3>
            <h3>Time :<?php echo $time;?></h3>
        </div>
        </section>
        <?php
        }
      }   
else
{
?>
   <h1 style="color:blue; margin: 300px 450px; font-size: 50px">No Booking !!!!</h1>
<?php
}
 ?>
</div>
</div>
</div>
</body>
</html>

