<?php
include("../admin/connection.php");

session_Start();
session_unset();
session_destroy();
?>
<script language="javascript">
document.location="../index.php";
</script>
<?php

?>