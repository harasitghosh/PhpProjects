<?php
include "../admin/connection.php";

$name=$_POST['nm'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$password=$_POST['pass'];
$confirmpassword=$_POST['cpass'];

if ($password!=$confirmpassword)
{
?>
<script language="javascript">
alert('Password does not matched');
window.history.go(-1);
</script>
<?php
}
else
{
    $f=0;
	 $getta = mysqli_query($conn, "select * from main_signup where mailadres='$email' and username='$contact' ") or die(mysqli_error());

    while ($ro = mysqli_fetch_array($getta)) 
    {
		$f++;
	}
    if($f==0)
    {
       $datetime = date('d/m/Y');
        $query="INSERT INTO main_signup (username,password,name,mob,mailadres,userlevel,signupdate) VALUES ('$contact','$password','$name','$contact','$email','1','$datetime')";
        $result = mysqli_query($conn,$query) or die (mysqli_error());
    ?>
    
      <script language="javascript">
    alert('Succesfully Submitted');
    document.location="login.php";
    </script>
<?php
}

else
{
    ?>
      <script language="javascript">
    alert('Phnone number alraedy Exists');
    document.location="signup.php";
    </script>

<?php
}
}
?>