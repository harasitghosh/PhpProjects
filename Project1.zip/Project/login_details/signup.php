<!DOCTYPE html>
<!-- === Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="../css/register.css">

    <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>SignUp</title>
    <script>
        function validation() {
            var name = document.getElementById('nm').value;
            var contact = document.getElementById('contact').value;
            var pass = document.getElementById('pass').value;

            if(name.length <2 ) {
                alert("name should be more than 1 character");
                //document.getElementById('nm').innerHTML=" name should be more than 1 character";
                return false;
            }
            if (name.match(/[0-9!@#$%^&*)(~`',."]/) != null) {
                alert("Username cannot contain number or special chars");
            return false;
            }
            if(pass.length<6) {
                alert("Password must be 6 character long and 1 Capital letter and  1 numeric number and 1 Special symbol");
                return false;
            }
            if(pass.search(/[A-Z]/)==-1) {
                alert("Password must contain atleast 1 Capital letter");
                return false;
            }
            if(pass.search(/[0-9]/)==-1) {
                alert("Password must contain atleast 1 numeric number");
                return false;
            }
            if(pass.search(/[!\@#$%^&*()|?><]/)==-1) {
                alert("Password must contain atleast 1 Special symbol");
                return false;
            }
            
            if(isNaN(contact)) {
                alert("Plz Write Numbers Only");
                return false;
            }
            if((contact.length<10) || (contact.length>10) ) {
                alert("Contact Number must 10 digit");
                return false;
            }
            
        }
    </script>
   
    <script>
    const container = document.querySelector(".container"),
      pwShowHide = document.querySelectorAll(".showHidePw"),
      pwFields = document.querySelectorAll(".password"),
      signUp = document.querySelector(".signup-link"),
      login = document.querySelector(".login-link");

    //   js code to show/hide password and change icon
    pwShowHide.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })
</script>
</head>
<body>
    <div class="container">
        <div class="forms">
            <div class="form login">
                <span class="title">Register</span>

                <form action="signup_value.php" method="post" onsubmit="return validation()">
                    <div class="input-field">
                        <input type="text"  name="nm" id="nm" placeholder="Enter your Name" required>
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <span id="name-info"></span>
                    </div>

                    <div class="input-field">
                        <input type="text"  name="contact" id="contact" placeholder="Enter your Number" required>
                       <i class="fa fa-phone-square" aria-hidden="true"></i>
                       <span id="contact-info"></span>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password"  name="pass" id="pass" placeholder="Enter your password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                        <span id="pass-info"></span>
                    </div>

                    <div class="input-field">
                        <input type="text"  name="cpass" id="cpass" placeholder="Confirm Your Password" required>
                        <i class="uil uil-lock icon"></i>
                        <span id="cpass-info" class="text-danger  font-weight-bold"></span>
                       
                    </div>

                    <div class="input-field">
                        <input type="email"  name="email" placeholder="Enter your Email ID" required>
                        <i class="uil uil-envelope icon"></i> 
                        <span id="email-info"></span>
                    </div>
                    

                    <div class="input-field button">
                        <input type="submit" name="submit" value="SignUp Now">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Already Have Account?
                        <a href="login.php" class="text signup-link">LogIn now</a>
                    </span>
                </div>
            </div>
            </div>
        </div>
    </div>
</body>
</html>