<?PHP
include "../admin/ck.php";
include("../admin/connection.php");
if(isset($_POST["username"]))
{
$username1 = $_POST['username'];
$password1 = $_POST['password'];

// check it the username exist
$query = mysqli_query($conn,"Select * from main_signup where username='$username1'");
 if ($row = mysqli_fetch_array($query))	
 {
// finally we check the database to see if the password is correct, if not skip to this if's else case

			if ($row["password"] == $password1)
			{
				$last_login=$row["lastlogin"];
				date_default_timezone_set("asia/kolkata");

				// we determin the date for the lastlogin - field.

				$datetime = date('d/m/Y h:i:sa', time());

				// and we update that field

				$querya = "UPDATE main_signup Set lastlogin = '$datetime' where username='$username1'";

				$result = mysqli_query($conn,$querya)or die (mysqli_error());

				session_start();

				// remove al the data from the session (auto logoff)

				session_unset();

				$_SESSION['pass'] = $password1;

				// put the username in the session

			//	session_register("id");

				$_SESSION['id'] = $username1;

				// session_register("last_login");

				$_SESSION['lastlog'] = $last_login;

				// send the the cookie if needed

				// go to the secured page.
						 
				if($row['userlevel']==1){
					header("Location: ../user.php");
				} 

				elseif($row['userlevel']==2){
					header("Location: ../index.php");
				}

				else{
					header("Location: ../admin/category.php");

				}

			}

			else
			{
			?>
			<script>
				alert("Password Missmatched !");
				//window.document.location="login.php";
				window.history.back();
				</script>	
				<?php
			}

	}
	else
	{
	?>
		<script>
		alert("Invalid ID!");
		//window.document.location="login.php";
		window.history.back();
		</script>	
	<?php
	}
}
?>