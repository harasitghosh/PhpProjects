<?php
include "connection.php";

$sl=$_REQUEST['sl'];
$stat=$_REQUEST['stat'];


$query = "update category set stat='$stat' where sl='$sl'";
$result = mysqli_query($conn,$query)or die (mysqli_error());
?>
<script language="javascript">
alert('Done Successfully. Thank You');
document.location="category.php";
</script>
