<?php
include "header.php";
include "connection.php";
?>
<html>
<head>
    <title>Document</title>
    <link rel="stylesheet" href="../css/category.css">
</head>
<body><br>
    <form action="value1.php" method="post">
        
    <table align="center" style="border-radius:20px; background-color: transparent;"> <br><br><br>
        <tr>
            <td>Service Category : </td>
            <td><input type="text" name="cat" placeholder="Enter Service category"></td>
        </tr> 
             <tr>
             <td colspan="2" align="center"><input type="submit" name="submit" class="button"></td>

            </tr>
    </table> <br>
    </form>
    <table border="1" align="center">
        <tr>
        <th>Sl</th>
        <th>Catagory</th>
        <th colspan="3">Operation</th>
        </tr>

        <?php
           
           $f=0;
           $query=mysqli_query($conn, "select * from category order by sl") or die (mysqli_error());
           while($data=mysqli_fetch_array($query))
           {   
               $f++;
               $sl=$data['sl'];
               $cat=$data['catnm'];
               $stat=$data['stat'];

            ?>

               <tr>
                <td> <?php echo $f; ?> </td>
                <td> <?php echo $cat; ?> </td>
                <td><a href="edit1.php?sl=<?php echo $sl; ?>" title="Click to Edit"><img src="../images/img/edit.png" height="25px"></a></td>
                <?php
                if($stat==1)
                {
                    ?>
                <td><a href="active1.php?sl=<?php echo $sl; ?>&stat=0" title="Click to De-active"> De-active</a></td>
                 <?php
                }
                else
                {
                ?>
                <td><a href="active1.php?sl=<?php echo $sl; ?>&stat=1" title="Click to Active"> Active</a></td>
                <?php
                }
                ?>
        <?php    
           }
           ?>    
    </table> <br>
    <div class="link" >
            <a href="subcategory.php">Sub Category</a>
    </div>
</body>
</html>
<?php
include "footer.php";
?>