<?php
include "connection.php";

$catnm=$_POST['cat'];
$subcat=$_POST['subcat'];

$query = "INSERT INTO subcategory (catid,subcat) VALUES ('$catnm','$subcat')";
$result = mysqli_query($conn,$query) or die (mysqli_error());
?>

<script language="javascript">
alert('Submited Successfully. Thank You');
document.location="subcategory.php";
</script>