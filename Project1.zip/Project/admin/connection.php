<?php
$server="localhost";
$username="root";
$password="";
$database="service";

$e1= "Could not connect to Server<BR>\n please check your settings in config.php";
$e2 = "Could not open database<BR>\n please check your settings in config.php";

$conn = @mysqli_connect($server,$username,$password) or die ($e1); 
mysqli_select_db($conn,$database) or die ($e2);
?>