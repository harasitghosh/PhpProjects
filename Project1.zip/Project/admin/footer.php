<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

      <!--====== Title ======-->
      <title>Document</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="images\favicon.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="css\slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="css\animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="css\nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="css\jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="css\magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="css\bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="css\font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="css\default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="css\style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="css\responsive.css">
  
</head>
<body>
    <!--====== FOOTER PART START ======-->
    <footer id="footer-part">
        <div class="footer-top pt-40 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <a href="#"><img src="images\logo-2.png" alt="Logo"></a>
                            </div>
                            <p>Gravida nibh vel velit auctor aliquetn quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate.</p>
                            <ul class="mt-20">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sitemap</h6>
                            </div>
                            <ul>
                                <li><a href="../index.php"><i class="fa fa-angle-right"></i>Home</a></li>
                                <li><a href="../about.html"><i class="fa fa-angle-right"></i>About us</a></li>

                            </ul>
                            <ul>

                                <li><a href="../services.html"><i class="fa fa-angle-right"></i>Services</a></li>
                                <li><a href="../contact.html"><i class="fa fa-angle-right"></i>Contact</a></li>
                            </ul>
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-link support mt-40">
                            <div class="footer-title pb-25">
                                <h6>Support</h6>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>FAQS</a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Privacy & policy</a></li>
                            </ul>
                        </div> <!-- support -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Contact Us</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <div class="cont">
                                        <p>32 Mahatma Gandhi Road, North Kolkata </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+3 123 456 789</p>
                                    </div>
                                </li>
                                
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
        
        <div class="footer-copyright pt-10 pb-25">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="copyright text-md-left text-center pt-15">
                            <p>&copy; Copyrights 2019 Edubin All rights reserved. </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="copyright text-md-right text-center pt-15">
                            <p>Designed by <span>Harasit</span> </p>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>
    <!--====== FOOTER PART ENDS ======-->



    <!--====== jquery js ======-->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js\vendor\modernizr-3.6.0.min.js"></script>
    <script src="js\vendor\jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="js\bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="js\slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="js\jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="js\waypoints.min.js"></script>
    <script src="js\jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="js\jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="js\jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="js\jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="js\validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="js\ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="js\main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="js\map-script.js"></script>
    
</body>
</html>