<?php
include "connection.php";

$catnm=$_POST['cat'];

$query = "INSERT INTO category (catnm) VALUES ('$catnm')";
$result = mysqli_query($conn,$query) or die (mysqli_error());
?>

<script language="javascript">
alert('Submited Successfully. Thank You');
document.location="category.php";
</script>