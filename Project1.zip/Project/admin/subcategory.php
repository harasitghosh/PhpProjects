<?php
include "header.php";

include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="../css/subcategory.css">
</head>
<body>
    <form action="value2.php" method="post">
    <table align="center" style="border-radius:20px; background-color: transparent;"> <br><br><br><br><br><br>
        <tr>
            <td>Category</td>
            <td>
                <select class="select" name="cat" style="width:200px;">
                    <option value="">---select---</option>
                    <?php
                     $query=mysqli_query($conn,"select * from category order by sl") or die (mysqli_error());
                     while($data=mysqli_fetch_array($query))
                     {
                         $cat_id=$data['sl'];
                         $catnm=$data['catnm'];
                    ?>
                    <option value="<?php echo $cat_id;?>"> <?php echo $catnm ;?></option>
                    <?php
                     }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Sub Category</td>
            <td><input type="text"name="subcat" placeholder="Enter SubCategory"></td>
        </tr>
        <tr>
                <td colspan="2" align="center"><input type="submit" name="submit" class="button"></td>
         </tr>
    </table>
</form> <br> <br>

<table border="3" align="center" style=" background-color: transparent ;border-radius:10px;">
        <tr>
        <th>Sl.</th>
        <th>Catagory</th>
        <th>Sub Category</th>
        <th colspan="3">Operation</th>
        </tr>

        <?php
           
           $f=0;
           $query=mysqli_query($conn, "select * from subcategory order by sl") or die (mysqli_error());
           while($data=mysqli_fetch_array($query))
           {   
               $f++;
               $sl=$data['sl'];
               $catid=$data['catid'];
               $subcat=$data['subcat'];
               $stat=$data['stat'];

               		
		$get=mysqli_query($conn,"select * from category where sl='$catid'") or die(mysqli_error());
        while($ro1=mysqli_fetch_array($get))
        {	
            $catnm=$ro1['catnm'];
        }	

            ?>

               <tr style= "color:white;">
                <td> <?php echo $f; ?> </td>
                <td> <?php echo $catnm; ?> </td>
                <td><?php echo $subcat ;?></td>
                <td><a href="edit2.php?sl=<?php echo $sl; ?>" title="Click to Edit"><img src="../images/img/edit.png" height="25px"></a></td>

                <?php
                if($stat==1)
                {
                    ?>
                <td><a href="active2.php?sl=<?php echo $sl; ?>&stat=0" title="Click to De-active"> De-active</a></td>
                 <?php
                }
                else
                {
                ?>
                <td><a href="active2.php?sl=<?php echo $sl; ?>&stat=1" title="Click to Active"> Active</a></td>
                <?php
                }
                ?>
        <?php    
           }
           ?>    
    </table> <br><br>
    
    <div class="link" >
            <a href="category.php">Category</a>
    </div>
</body>
</html>
<?php
include "footer.php";
?>