<?php
include "login_details/ck.php";
include "header.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>    
<title>Document</title>
<link rel="stylesheet" href="css\user.css">
<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
     <script>
        function validation() {
            var name = document.getElementById('nm').value;
            var contact = document.getElementById('contact').value;
            var pass = document.getElementById('pass').value;

            if(name.length <2 ) {
                alert("name should be more than 1 character");
                return false;
            }
            if (name.match(/[0-9!@#$%^&*)(~`',."]/) != null) {
                alert("Username cannot contain number or special chars");
            return false;
            }
            if((contact.length<10) || (contact.length>10) ) {
                alert("Contact Number must 10 digit");
                return false;
            }
            
        }
    </script>
<script>
function fun(cat)
 { 
    //alert(cat);
    $('#divsubcat').load('getsubcat.php?cat='+cat).fadeIn('fast');
 }
</script>
<link rel="stylesheet" href="../css/user.css">

</head>
<body> <br><br><br>
     
    <form action="value3.php" method="post" enctype="multipart/form-data">
        <table border="0" align="center"> <br>
        <tr>
            <td colspan="2"><input type="file" name="file" id="file" data-error="Profile pic is required." required="required"></td>
        </tr>
            <tr>
                <td>Category</td>
                <td>

                <select name="cat" id="cat" onchange="fun(this.value)" data-error="Name is required." required="required">
                    <option value="0">Choose Category</option>
                    <?php
                    $query=mysqli_query($conn,"select * from category order by sl") or die (mysqli_error());
                    while($data=mysqli_fetch_array($query))
                    {
                        $catid=$data['sl'];
                        $catnm=$data['catnm'];
                        ?>
                    <option value="<?php echo $catid;?>"> <?php echo $catnm ;?></option>
                    <?php
                    }
                    ?>
                </select>

                </td>
                <tr>
                    <td>Sub Category</td>
                    <td>
                    <div  id="divsubcat" >
                        <select name="subcat" id="subcat" data-error="Name is required." required="required" style="width:70px">
                            <option value="">--select--</option>
                        </select>
                    </div>
                    </td>
                </tr>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="nm" id="nm" autocomplete="off" data-error="Name is required." required="required"></td>
            </tr>
            <tr>
                <td>Contact No</td>
                <td><input type="text" name="no" id="no" autocomplete="off" data-error="valid Number is required." required="required" value="<?php echo $user_currently_loged;?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" autocomplete="off" data-error="Valid Email is required." required="required"></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><textarea name="add" id="add" cols="25" rows="2" autocomplete="off" data-error="Address is required." required="required"></textarea></td>
            </tr>

            
            <tr>
                <td colspan="2" align="center"><input type="submit" name="submit" class="button"></td>
            </tr>
        </table>
    </form> <br>

    <table border="3" align="center" style=" background-color: transparent ;border-radius:15px; color:white;">
    <tr>
        <th>Sl</th>
        <th>Catagory</th>
        <th>Sub Category</th>
        <th>Name</th>
        <th>Contact</th>
        <th>Email</th>
        <th>Address</th>
        <th colspan="3">Operation</th>
        </tr>

        <?php
           
           $f=0;
           $query=mysqli_query($conn, "select * from user where contact='$user_currently_loged' order by sl") or die (mysqli_error());
           while($data=mysqli_fetch_array($query))
           {   
               $f++;
               $sl=$data['sl'];
               $catid=$data['catnm'];
               $subcatid=$data['subcat'];
               $name=$data['name'];
               $contact=$data['contact'];
               $email=$data['email'];
               $address=$data['address'];
               $stat=$data['stat'];

           $query2=mysqli_query($conn, "select * from category  where sl='$catid'") or die (mysqli_error());
           while($data2=mysqli_fetch_array($query2))
           {   
               $catnm=$data2['catnm'];
           }
            
           $query3=mysqli_query($conn, "select * from subcategory  where sl='$subcatid'") or die (mysqli_error());
           while($data3=mysqli_fetch_array($query3))
           {   
               
               $subcat=$data3['subcat'];
           }
          ?>

               <tr>
                <td> <?php echo $f; ?> </td>
                <td> <?php echo $catnm; ?> </td>
                <td><?php echo $subcat;?></td>
                <td><?php echo $name ;?></td>
                <td><?php echo $contact ;?></td>
                <td><?php echo $email ;?></td>
                <td><?php echo $address ;?></td>
                <td></td>
                <td><a href="edit3.php?sl=<?php echo $sl; ?>" title="Click to Edit"><img src="images/img/edit.png" height="25px"></a></td>

                <?php
                if($stat==1)
                {
                ?>
                <td><a href="active3.php?sl=<?php echo $sl; ?>&stat=0" title="Click to De-active"> De-active</a></td>
                 <?php
                }
                else
                {
                ?>
                <td><a href="active3.php?sl=<?php echo $sl; ?>&stat=1" title="Click to Active"> Active</a></td>
                <?php
                }
                ?>
        <?php    
           }
           ?>    
    </table> <br><br>
</body>
</html>

<?php
include "footer.php";
?>